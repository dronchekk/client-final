//
//  NewsItemTypes.swift
//  Dz1Storyboar Rad
//
//  Created by Andrey Rachitskiy on 08.01.2022.
//

import UIKit

enum NewsItemType {

    case text
    case image(count: Int)
}
