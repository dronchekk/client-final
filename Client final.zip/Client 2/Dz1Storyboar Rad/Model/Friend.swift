//
//  Friend.swift
//  Dz1Storyboar Rad
//
//  Created by Andrey rachitsky on 16.10.2021.
//

import UIKit

struct Friend {
    var name = String()
    var avatar = UIImage()
    var photos = [UIImage]()
}

