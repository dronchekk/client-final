//
//  FriendsViewController+FillData.swift
//  Dz1Storyboar Rad
//
//  Created by Andrey rachitsky on 23.10.2021.
//

import UIKit
 
//extension FriendsViewController {
//    func fillFriendsArray() {
//        let friend1 = Friend(name: "IronMan", avatar: UIImage(named: "Friend1avatar")!, photos: [UIImage(named: "Friend1_1")!, UIImage(named: "Friend1_2")!, UIImage(named: "Friend1_3")!])
//        let friend2 = Friend(name: "Thor", avatar: UIImage(named: "Friend2avatar")!, photos: [UIImage(named: "Friend2_1")!, UIImage(named: "Friend2_2")!, UIImage(named: "Friend2_3")!])
//        let friend3 = Friend(name: "Hulk", avatar: UIImage(named: "Friend3avatar")!, photos: [UIImage(named: "Friend3_1")!, UIImage(named: "Friend3_2")!, UIImage(named: "Friend3_3")!])
//        let friend4 = Friend(name: "SpiderMan", avatar: UIImage(named: "Friend4avatar")!, photos: [UIImage(named: "Friend4_1")!, UIImage(named: "Friend4_2")!, UIImage(named: "Friend4_3")!,])
//        friendsArray.append(friend1)
//        friendsArray.append(friend2)
//        friendsArray.append(friend3)
//        friendsArray.append(friend4)
//    }
//}
