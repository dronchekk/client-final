//
//  FacebookauthorizationViewController.swift
//  Dz1Storyboar Rad
//
//  Created by Andrey rachitsky on 17.11.2021.
//

import UIKit

class FacebookauthorizationViewController: UIViewController {
    @IBOutlet weak var loginTextField: UITextField!
    @IBOutlet weak var authorizationButton: UIButton!
    
    @IBOutlet weak var forgotPasswordButton: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var fBLogo: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
